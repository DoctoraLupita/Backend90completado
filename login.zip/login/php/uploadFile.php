<?php
session_start();

include 'conexion_be.php';

$files = $_FILES["files"];

$correo = $_SESSION['usuarios'];
$consulta = "SELECT * FROM usuarios WHERE correo='$correo'";
$resultado = mysqli_query($conexion, $consulta);

if (mysqli_num_rows($resultado) > 0) {
    $fila = mysqli_fetch_assoc($resultado);
    $id_user = $fila['id'];
}else{
    $id_user = null;
}

$user = $id_user;

for ($i = 0; $i < count($files['name']); $i++) {
    // Obtener el contenido del archivo
    $fileTmpPath = $files['tmp_name'][$i];
    $fileName = $files['name'][$i];
    $fileSize = $files['size'][$i];
    $fileType = $files['type'][$i];

    // Leer el contenido del archivo
    $fileContent = file_get_contents($fileTmpPath);

    // Convertir el contenido a base64
    $base64File = base64_encode($fileContent);
    
    $query = "INSERT INTO archivos(user, files)
    VALUES('$user', 'data:$fileType;base64,$base64File')";

    $result_query = mysqli_query($conexion, $query);
}

header('Location: /login/lucero/vistas/especialistas.html');


?>