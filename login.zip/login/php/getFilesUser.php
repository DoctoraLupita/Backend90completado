<?php
session_start();

include 'conexion_be.php';

$correo = $_SESSION['usuarios'];
$consulta = "SELECT * FROM usuarios WHERE correo='$correo'";
$resultado = mysqli_query($conexion, $consulta);

if (mysqli_num_rows($resultado) > 0) {
    $fila = mysqli_fetch_assoc($resultado);
    $id_user = $fila['id'];
}else{
    $id_user = null;
}

$user = $id_user;

$consulta_archivos = "SELECT usuarios.nombre_completo, usuarios.correo, archivos.files FROM archivos  JOIN usuarios ON archivos.user = usuarios.id WHERE USER='$user'";
$resultado_archivos = mysqli_query($conexion, $consulta_archivos);

$archivos = array();

if (mysqli_num_rows($resultado) > 0) {
    while ($fila = mysqli_fetch_assoc($resultado_archivos)) {
        $archivos[] = $fila;
    }
}

echo json_encode($archivos);