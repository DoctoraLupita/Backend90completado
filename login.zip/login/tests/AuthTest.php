<?php

require_once __DIR__ . '\src\Auth.php'; 
require_once __DIR__ . '\src\User.php'; 

use PHPUnit\Framework\TestCase;

class AuthTest extends TestCase {
    private $auth;
    private $conexion;

    protected function setUp(): void {
        $this->conexion = new mysqli("localhost", "root", "", "login_register_db");
        $this->auth = new Auth($this->conexion);
    }

    public function testRegisterUser() {
        $correo = 'test@example.com';
        $contrasena = 'password123';

        $result = $this->auth->register($correo, $contrasena);
        $this->assertTrue($result);
    }
}

?>