<?php


class Auth {
    private $users = [];

    public function register($email, $password) {
        foreach ($this->users as $user) {
            if ($user->getEmail() === $email) {
                return false;
            }
        }

        $this->users[] = new User($email, $password);
        return true;
    }

    public function login($email, $password) {
        foreach ($this->users as $user) {
            if ($user->getEmail() === $email && password_verify($password, $user->getPassword())) {
                return true;
            }
        }

        return false;
    }
}
?>