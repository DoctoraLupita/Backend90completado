<?php
class User {
    private $correo;
    private $contrasena;

    public function __construct($correo, $contrasena) {
        $this->correo = $correo;
        $this->contrasena = $contrasena;
    }

    public function getCorreo() {
        return $this->correo;
    }

    public function getContrasena() {
        return $this->contrasena;
}
}
?>