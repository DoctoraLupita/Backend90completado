<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '\src\User.php';

class UserTest extends TestCase {
    public function testUserCreation() {
        $correo = 'test@example.com';
        $contrasena = 'password123';

        $user = new User($correo, $contrasena);
        
        // Verifica que el método getCorreo() funcione correctamente
        $this->assertEquals($correo, $user->getCorreo());

        // Puedes agregar más aserciones para otros atributos si es necesario
        $this->assertEquals($contrasena, $user->getContrasena());
    }
}
?>