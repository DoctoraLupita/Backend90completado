async function obtenerArchivos() {
    try {
        const response = await fetch('http://localhost/login/php/getFilesUser.php');
        const data = await response.json();
        
        const gallery = document.getElementById('container-gallery');

        data.forEach(archivo => {
            gallery.innerHTML += `
                <div class="content-gallery-img"><img src="${archivo.files}"/></div>
            `;
        });
    } catch (error) {
        console.error('Error al obtener los datos:', error);
    }
}

// Llamar a la función para obtener y mostrar los datos
obtenerArchivos();